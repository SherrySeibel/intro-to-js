README.txt

CSCI E-3 Introduction to Web Programming Using Javascript
Harvard University Extension School 
UnitProject#1

This is a README file. It’s a common way for developers to provide basic information to each other about a program - how it works, technical user documentation, contact information for the author, copyright, etc. 

To see the instructions for this assignment, open the file project1.html (in the folder PartA) in your browser and follow the directions.

